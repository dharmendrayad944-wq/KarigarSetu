# SIH26090 — Artisan Heritage AI Assistant

## MVP Goal
Build an artisan-first AI onboarding assistant that converts a product photo and local-language voice description into a verified, marketplace-ready listing while preserving craft/heritage metadata.

## Core Flow
Artisan Login → Dashboard → Add Product → Upload Photo + Record/Upload Voice → AI Analysis → Editable Listing + Heritage Profile → Artisan Approval → Catalogue

## Recommended Stack
- Next.js (App Router) + TypeScript
- Tailwind CSS
- Supabase Auth, Postgres and Storage
- Gemini multimodal model for image + language understanding
- Speech-to-text layer compatible with Indian languages
- Zod for validation

## MVP Pages
- /
- /login
- /dashboard
- /products/new
- /products/[id]/review
- /catalogue
- /heritage/[id]

## Important Product Principle
This is not another marketplace. It is an artisan-side digital onboarding and heritage-preservation layer that can later connect to marketplaces/ONDC.

## Source Requirement
Keep all AI-generated cultural facts clearly separated from artisan-provided facts and verified external metadata. The artisan must approve before publication.
