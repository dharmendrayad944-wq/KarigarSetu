# SIH26090 MVP Implementation Checklist

## Phase A — Foundation
- [ ] Next.js + TypeScript project
- [ ] Tailwind setup
- [ ] Supabase client/server utilities
- [ ] Environment variable handling
- [ ] Global design system
- [ ] Mobile navigation

## Phase B — Authentication
- [ ] Registration
- [ ] Login
- [ ] Logout
- [ ] Artisan profile
- [ ] Protected dashboard routes

## Phase C — AI Listing Flow
- [ ] Image upload
- [ ] Voice recording/upload
- [ ] Text fallback
- [ ] Processing state
- [ ] Demo AI response
- [ ] Editable result

## Phase D — Heritage
- [ ] Heritage profile editor
- [ ] Claim source labels
- [ ] Verification status
- [ ] Artisan story

## Phase E — Publishing
- [ ] Draft
- [ ] Review
- [ ] Approval
- [ ] Catalogue
- [ ] Product detail
- [ ] Heritage detail

## Phase F — Quality
- [ ] Error handling
- [ ] Empty states
- [ ] Responsive UI
- [ ] Accessibility
- [ ] Browser test
- [ ] README
- [ ] Demo seed data
